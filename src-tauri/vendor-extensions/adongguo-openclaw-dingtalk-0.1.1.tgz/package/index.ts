import type { ClawdbotPluginApi } from "clawdbot/plugin-sdk";
import { emptyPluginConfigSchema } from "clawdbot/plugin-sdk";
import { dingtalkPlugin } from "./src/channel.js";
import { setDingTalkRuntime } from "./src/runtime.js";

export { monitorDingTalkProvider } from "./src/monitor.js";
export {
  sendMessageDingTalk,
  sendMarkdownDingTalk,
  sendActionCardDingTalk,
  sendViaWebhook,
  sendDingTalkMessage,
  sendDingTalkTextMessage,
} from "./src/send.js";
export {
  uploadMediaDingTalk,
  downloadMediaDingTalk,
  sendImageDingTalk,
  sendFileDingTalk,
  sendMediaDingTalk,
  buildMediaSystemPrompt,
  processLocalImages,
  getOapiAccessToken,
} from "./src/media.js";
export { probeDingTalk } from "./src/probe.js";
export {
  addReactionDingTalk,
  removeReactionDingTalk,
  listReactionsDingTalk,
  DingTalkEmoji,
} from "./src/reactions.js";
export { dingtalkPlugin } from "./src/channel.js";

// AI Card streaming
export {
  createAICard,
  streamAICard,
  finishAICard,
  failAICard,
  getAccessToken,
  clearAccessTokenCache,
  AICardStatus,
  type AICardInstance,
  type AICardStatusType,
} from "./src/ai-card.js";

// Session management
export {
  isNewSessionCommand,
  getSessionKey,
  clearSession,
  getSessionInfo,
  clearAllSessions,
  getActiveSessionCount,
  cleanupExpiredSessions,
  getNewSessionCommands,
  DEFAULT_SESSION_TIMEOUT,
  type UserSession,
} from "./src/session.js";

// Gateway streaming
export {
  streamFromGateway,
  getGatewayCompletion,
  type GatewayOptions,
} from "./src/gateway-stream.js";

// Streaming message handler
export {
  handleDingTalkStreamingMessage,
  shouldUseStreamingMode,
  type StreamingHandlerParams,
} from "./src/streaming-handler.js";

const plugin = {
  id: "dingtalk",
  name: "DingTalk",
  description: "DingTalk channel plugin",
  configSchema: emptyPluginConfigSchema(),
  register(api: ClawdbotPluginApi) {
    setDingTalkRuntime(api.runtime);
    api.registerChannel({ plugin: dingtalkPlugin });
  },
};

export default plugin;
